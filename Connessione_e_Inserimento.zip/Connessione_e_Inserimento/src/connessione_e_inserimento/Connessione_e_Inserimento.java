/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connessione_e_inserimento;

import Tutto.LetturaFile;
import Tutto.PersonaCollection;
import Tutto.Contatto;
import Tutto.Utenti;
import Tutto.UtentiProvaider;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Marco
 */
public class Connessione_e_Inserimento {

    /**
     * @param args the command line arguments
     */
    static Scanner sc= new Scanner(System.in);
    static PersonaCollection InserimentoFile()
    {
        PersonaCollection listaPersone = new PersonaCollection();
        try {
            ArrayList <String> Righe = LetturaFile.leggiFile("jeyhe-t2295.csv");
            
            for (String s : Righe) 
            {
                listaPersone.aggiungi(Contatto.parse(s));
            }
            
        } catch (IOException ex) {
            Logger.getLogger(Connessione_e_Inserimento.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listaPersone;
    }
    public static void main(String[] args) {
       
        System.out.println("Inserire Nome Utente");
       String nome = sc.nextLine();
       
       System.out.println("Inserire Numero di telefono");
       String numero = sc.nextLine();
       
       Utenti u = new Utenti(0, nome, numero);
        UtentiProvaider.InserisciUtente(u);
        
        u.setIdUtente(UtentiProvaider.getLastUtente());
        
       
        
        PersonaCollection p = InserimentoFile();
        System.out.println("");
        
        for (Contatto contatto : p) {
            UtentiProvaider.InserisciContatto(contatto, u.getIdUtente());
        }
        
    }
    
}
