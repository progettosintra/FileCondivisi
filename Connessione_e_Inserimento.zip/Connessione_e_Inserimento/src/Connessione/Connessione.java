/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Connessione;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Marco
 */
public class Connessione {
    public static final String JDBC = "com.mysql.jdbc.Driver";
    public static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/sintra";
    
    public static Connection getConnection(){
       Connection connessione=null;
  
       try {
           Class.forName(JDBC).newInstance();
            connessione=DriverManager.getConnection(DB_URL, "root", "");
            } catch (Exception e) {
                e.printStackTrace();
            System.out.println("errore 1");
            System.out.println(e.toString());
       
          
       }
       return connessione;
   }

}
