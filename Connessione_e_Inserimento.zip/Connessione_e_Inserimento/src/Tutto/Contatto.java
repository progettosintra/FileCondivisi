/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tutto;

import java.util.ArrayList;

/**
 *
 * @author lello
 */
public class Contatto 
{
    String nome;
    String numeroDiTelefono;
    String cognome;

    /**
     * Creo un nuovo oggetto persona
     * @param nome Nome della parsona in rubrica
     * @param numeroDiTelefono Numero di telefono di questa perosona 
     * @param cognome Cognome della parsona
     */
    public Contatto(String nome, String numeroDiTelefono, String cognome) {
        this.nome = nome;
        this.cognome = cognome;
        this.numeroDiTelefono = numeroDiTelefono;
    }
    /**
     * Data una stringa csv la converte in un oggetto persona
     * @param riga Riga da convertire
     * @return La persona convertita
     */
    public static Contatto parse(String riga)
    {
        //Nome indice 0
        //Cognome indice 1
        //Numero di telefono indice 7
        
        String div[] = riga.split(",");
        String nome = div[0];
        String cognome = div[2];
        try {
            String numeroDiTelefono = div[12];
            return new Contatto(nome, numeroDiTelefono, cognome);
        } catch (Exception e) {
            return null;
        }
        
        
    }
    
}
