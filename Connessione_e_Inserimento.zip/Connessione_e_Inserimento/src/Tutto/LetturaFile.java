/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tutto;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author lello
 */
public class LetturaFile 
{
    public static ArrayList<String> leggiFile(String nomeFile) throws IOException
    {
        ArrayList <String> ret = new ArrayList();
        try {
            FileReader fr = new FileReader(nomeFile);
            BufferedReader br = new BufferedReader(fr);
            
            String testoLetto = "";
            while((testoLetto = br.readLine()) != null)
            {
                ret.add(testoLetto);
            }
            return ret;
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(LetturaFile.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return null;
    }
}
