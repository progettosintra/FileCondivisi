/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tutto;

/**
 *
 * @author Marco
 */
public class Utenti {
    private int IdUtente;
    private String Nome;
    private String Numero;

    public Utenti(int IdUtente, String Nome, String Numero) {
        this.IdUtente = IdUtente;
        this.Nome = Nome;
        this.Numero = Numero;
    }

    public int getIdUtente() {
        return IdUtente;
    }

    public String getNome() {
        return Nome;
    }

    public String getNumero() {
        return Numero;
    }

    public void setIdUtente(int IdUtente) {
        this.IdUtente = IdUtente;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public void setNumero(String Numero) {
        this.Numero = Numero;
    }
     
    
}
