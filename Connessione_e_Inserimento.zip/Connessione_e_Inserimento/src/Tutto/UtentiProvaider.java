/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tutto;

/**
 *
 * @author Marco
 */
import java.sql.*;
import Connessione.Connessione;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UtentiProvaider {
    static  Statement statemant=null;
   static Connection connessione=null;
   static ResultSet resultset=null;
   
   public static void TabellaUtente() 
    {
       connessione=Connessione.getConnection();
       
            try {
                    statemant=connessione.createStatement();
                    resultset = statemant.executeQuery("Select lista_utenti.IdUtente from lista_utenti order by IdUtente asc;");
                
                    while(resultset.next())
                    {
                            
                        String Nome=""; 
                        String NumerodiTelefono="";
                        int IdUtente=resultset.getInt("IdUtente");
                        Nome=resultset.getString("Nome");
                        NumerodiTelefono=resultset.getString("NumeroTelefono");
                                 try{
                                     NumerodiTelefono=resultset.getString("NumeroTelefono");
                                     Nome=resultset.getString("Nome");
                            
                                    } catch (Exception e) {
                                       NumerodiTelefono = "noNumber";
                                       Nome = "noName";
                                    } 
                                 
                           Utenti Ut = new Utenti(IdUtente, Nome, NumerodiTelefono);                       
                }
                
                statemant.close();     
                connessione.close();
                
                
                
            } catch (Exception ex) {
                
                System.out.println("errore 2");
                System.out.println(ex.toString());
            }
     
      
    }
   
   public static int getLastUtente() 
    {
       connessione=Connessione.getConnection();
       
            try {
                    statemant=connessione.createStatement();
                    resultset = statemant.executeQuery("Select lista_utenti.IdUtente from lista_utenti order by IdUtente asc;");
                
                    ArrayList <Integer> t = new ArrayList();
                    while(resultset.next())
                    {
                            
                        t.add(resultset.getInt("IdUtente"));
                }
                    statemant.close();     
                connessione.close();
                return t.get(t.size() - 1);
                
                
                
                
            } catch (Exception ex) {
                
                System.out.println("errore 2");
                System.out.println(ex.toString());
            }
     
            return -1;
    }
   public static void InserisciContatto(Contatto c, int id)
   {
       connessione=Connessione.getConnection();
       try {
           statemant=connessione.createStatement();
           String query = "INSERT INTO rubrica (NumeroTelefono, Nome, IdUtente)"
                   + " VALUES ('"
                   + c.numeroDiTelefono + "','"
                   + c.nome + "',"
                   + id
                   + ")";
           System.out.println(query);
           statemant.executeUpdate(query);
       } catch (Exception e) {
           e.printStackTrace();
       }
   }
   
   public static void InserisciUtente(Utenti ut)
   {
       connessione=Connessione.getConnection();
       try {
           statemant=connessione.createStatement();
           String query = "INSERT INTO lista_utenti (Numero, Nome)"
                   + " VALUES ('"
                   + ut.getNumero() + "','"
                   + ut.getNome() + "'"
                   + ")";
           System.out.println(query);
           statemant.executeUpdate(query);
       } catch (Exception e) {
           e.printStackTrace();
       }
   }
   
   
}
